package be.ugent.objprog.books;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

public class Main {

    private final Map<String, Book> catalog;

    public Main() {
        catalog = new HashMap<>();
        initCatalog();
    }

    private void initCatalog() {
        try {
            Document document = new SAXBuilder()
                    .build(getClass().getResourceAsStream("books.xml")).getDocument();
            Element root = document.getRootElement();
            for (Element entry : root.getChildren("book")) {
                String id = entry.getAttributeValue("id");
                catalog.put(id,
                        new Book(
                                id,
                                entry.getChildText("author"),
                                entry.getChildText("title"),
                                entry.getChildText("genre"),
                                entry.getChildTextTrim("description")
                        )
                );
            }

        } catch (IOException | JDOMException e) {
            throw new RuntimeException(e);
        }
    }

    public void run() {
        // printing all fantasy books
        for (Book book : catalog.values()) {
            if (book.genre().equals("Fantasy")) {
                System.out.println(book.title().toUpperCase());
                System.out.println(book.description());
            }
        }
    }

    public static void main(String[] args) {
        new Main().run();
    }
}
