open module books {

    requires java.xml;
    requires org.jdom2;

}