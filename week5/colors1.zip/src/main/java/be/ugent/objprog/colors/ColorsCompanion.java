package be.ugent.objprog.colors;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class ColorsCompanion {

    public Circle circle;

    public void doButton (ActionEvent event) {
        Button button = (Button) event.getSource();
        circle.setFill((Color) button.getUserData());
    }

}
