package be.ugent.objprog.books;

import java.util.HashMap;
import java.util.Map;

public class Main {

    private final Map<String, Book> catalog;

    public Main() {
        catalog = new HashMap<>();
        initCatalog();
    }

    private void initCatalog() {
        // TODO vul catalog op met alle boeken uit het bestand books.xml in be/ugent/objprogs/books
        //      sleutels zijn de book ids, waarden zijn records van het type Book

    }

    public void run() {
        // printing all fantasy books
        for (Book book : catalog.values()) {
            if (book.genre().equals("Fantasy")) {
                System.out.println(book.title().toUpperCase());
                System.out.println(book.description());
            }
        }
    }

    public static void main(String[] args) {
        new Main().run();
    }
}
