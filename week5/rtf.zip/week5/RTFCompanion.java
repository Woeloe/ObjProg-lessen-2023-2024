package week5;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class RTFCompanion {

    public TextField textField;
    public Button resetButton;

    public void reset() {
        textField.setText("");
    }

}
