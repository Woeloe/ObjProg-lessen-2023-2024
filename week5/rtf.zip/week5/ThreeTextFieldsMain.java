package week5;

import prog2.core.FXMLMain;

public class ThreeTextFieldsMain extends FXMLMain {

    public static void main(String[] args) {
        launch(args);
    }
}
