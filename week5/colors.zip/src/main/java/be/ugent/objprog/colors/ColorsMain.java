package be.ugent.objprog.colors;

import be.ugent.objprog.core.FXMLMain;

public class ColorsMain extends FXMLMain {

    public static void main(String[] args) {
        launch(args);
    }
}
