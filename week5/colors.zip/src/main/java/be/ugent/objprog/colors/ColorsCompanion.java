package be.ugent.objprog.colors;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class ColorsCompanion {

    public Circle circle;

    public void doButtonRed () {
        circle.setFill(Color.RED);
    }

    public void doButtonBlue () {
        circle.setFill(Color.BLUE);
    }

    public void doButtonGreen () {
        circle.setFill(Color.GREEN);
    }

}
