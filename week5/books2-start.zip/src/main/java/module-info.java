open module books {

    requires com.fasterxml.jackson.databind;

}