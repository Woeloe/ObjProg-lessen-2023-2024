package be.ugent.objprog.books;

public record Book(String id, String author, String title, String genre, String description) {
}
