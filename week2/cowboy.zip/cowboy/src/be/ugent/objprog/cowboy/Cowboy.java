package be.ugent.objprog.cowboy;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Cowboy {

    private final String spaces;

    private final List<List<String>> verses;

    private final int width;

    public Cowboy(int width) {
        this.verses = new ArrayList<>();
        this.width = width;
        this.spaces = " ".repeat(width);
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(
                        Cowboy.class.getResourceAsStream("cowboy.txt")
                ))) {
            for (int i = 0; i < 3; i++) {
                List<String> lines = new ArrayList<>();
                for (int j = 0; j < 9; j++) {
                    lines.add(reader.readLine());
                }
                verses.add(lines);
            }
        } catch (Exception ex) {
            throw new RuntimeException("'cowboy.txt' niet gevonden", ex);
        }
    }

    public void prettyPrint () {
        // het eerste couplet + refrein wordt links uitgelijnd
        for (List<String> verse : verses) {
            for (String line : verse) {
                System.out.println(line);
            }
        }

        // het tweede, gecentreerd
        for (List<String> verse : verses) {
            for (String line : verse) {
                System.out.println(spaces.substring(0, (width - line.length())/2) + line);
            }
        }

        // het derde, rechts uitgelijnd
        for (List<String> verse : verses) {
            for (String line : verse) {
                System.out.println(spaces.substring(0, width - line.length()) + line);
            }
        }
    }

    public static void main(String[] args) {
        new Cowboy(60).prettyPrint();
    }
}
