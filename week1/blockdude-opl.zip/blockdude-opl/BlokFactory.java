import greenfoot.Actor;

public class BlokFactory implements Factory {

    public Actor create () {
        return new Blok();
    }
    
}
