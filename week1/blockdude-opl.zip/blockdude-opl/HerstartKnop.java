// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Info-veld met daarop de tekst 'Herstart'. Klik je op dit veld, dan herstart het huidige niveau
 */
public class HerstartKnop extends Info
{

    /**
     * Maak een herstartknop aan (= Info-veld met vaste tekst "Herstart")
     */
    public HerstartKnop()
    {
        super("Herstart");
    }

    /**
     * Herstart het huidge niveau wanneer er op dit object wordt geklikt
     */
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            getWorldOfType(Grot.class).herstartNiveau();
        }
    }
}
