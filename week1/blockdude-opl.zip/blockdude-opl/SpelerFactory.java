import greenfoot.Actor;

public class SpelerFactory implements Factory {
    
    /* Opmerking
     
       Omdat je zowel een Speler met startrichting -1 als een speler met
       startrichting +1 moet kunnen aanmaken, heb je er misschien voor
       gekozen om twee afzonderlijke factories aan te maken voor spelers, een 
       SpelerPlus1 en een SpelerMin1-factory. 
       
       Dit is een valabel alternatief, maar kijk ook eens hoe
       we dit hier met een enkele factory-klasse hebben opgelost.
     */
    
    private final int richting;
    
    public SpelerFactory (int richting) {
        this.richting = richting;
    }

    public Actor create () {
        return new Speler(richting);
    }
    
}
