// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * De uitgang van de grot. Wanneer je de deur bereikt, ga je naar het volgende niveau.
 */
public class Deur extends Actor
{

    /**
     * De deur bepaalt of er naar een volgend niveau wordt overgegaan
     */
    public void act()
    {
        if (isTouching(Speler.class)) {
            getWorldOfType(Grot.class).volgendNiveau();
        }
    }
}
