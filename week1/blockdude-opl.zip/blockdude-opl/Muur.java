// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Een muur is een niet-beweegbaar object dat een obstakel vormt voor de speler. De grot is afgebakend door verschillende muren, zodat de speler niet uit het speelveld kan ontsnappen.
 */
public class Muur extends Actor
{

    /**
     * Een muur doet niets
     */
    public void act()
    {
        /* doet niets*/
    }
}
