// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Bevat beschrijvingen van hoe de verschillende niveaus zijn ingedeeld
 */
public class Indelingen
{
    /* Beschrijvingen van de verschillende niveaus met de volgende code: 0 = muur, x = blok, e = exit, < = mannetje dat naar links kijkt, > = mannetje dat naar rechts kijkt ,. = lege ruimte.*/
    private static final String[] LEVEL_0 = {"00000000000000000000", "0..................0", "0..................0", "0..................0", "0..................0", "0..................0", "0e..............<..0", "00000000000000000000"};
    private static final String[] LEVEL_1 = {"00000000000000000000", "0..................0", "0..................0", "0..................0", "0..................0", "0...0.......0......0", "0e..0...0.x.0.x.>..0", "00000000000000000000"};
    private static final String[] LEVEL_2 = {"0000000000000000000000", "00................0000", "00..................00", "0e..................00", "00...................0", "00...........0..x....0", "00...........0x.xx<..0", "000000...0000000000000", "000000..x0000000000000", "0000000000000000000000"};
    private static final String[] LEVEL_3 = {"0000000000000000000", "0000000000000000000", "0.000.............0", "0..0..............0", "0................x0", "0...............xx0", "0.000....<...0x.00.", "0.0.0....0..00000..", "e.0.0xx.00..0......", "000.000000.00......", "000.00...000......."};
    private static final String[] LEVEL_4 = {"000000000000000000000000", "000000000000000000000000", "000000000000000000000000", "0000000.00000000.....000", "000000...000000.......00", "000.......0000.........0", "00.........00..........0", "00....................x0", "00...................xx0", "00...............<...000", "00....0..........0...0..", "0e....0.x........00000..", "00000.0.x...x..000......", "....0.0.x.0.0x.0........", "....0.0000000000........", "....000................."};
    private static final String[] LEVEL_5 = {"0000000000000000000000", "000000..0000....000000", "0000...............000", "0....................0", "0....................0", "0.....0..............0", "0.....0..............0", "0.....0xxxx..........0", "0e...0000000<........0", "00.000.....00.0.....x0", ".0.0........0.00...xx0", ".0.0........0.00..xxx0", ".000........0.00000000", "............000......."};
    private static final String[][] INDELINGEN = {LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4, LEVEL_5};

    /**
     * Deze klasse bevat enkel klassenmethoden. Een constructor is dus niet nodig.
     */
    public Indelingen()
    {
    }

    /**
     * Het aantal niveaus dat wordt ondersteund
     */
    static public int size()
    {
        return INDELINGEN.length;
    }

    /**
     * Geeft de beschrijving terug van het niveau met het opgegeven nummer. Het startniveau heeft nummer 0.
     */
    static public String[] get(int nr)
    {
        return INDELINGEN[nr];
    }
}
