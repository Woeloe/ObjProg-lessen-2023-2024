import greenfoot.Actor;

public class DeurFactory implements Factory {

    public Actor create () {
        return new Deur();
    }
    
}
