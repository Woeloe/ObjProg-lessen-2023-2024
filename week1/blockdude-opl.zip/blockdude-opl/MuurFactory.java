import greenfoot.Actor;

public class MuurFactory implements Factory {

    public Actor create () {
        return new Muur();
    }
    
}
