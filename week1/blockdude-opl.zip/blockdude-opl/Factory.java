import greenfoot.Actor;

/**
 * Maakt een nieuwe actor aan. Toepassing van het 'factory'-patroon
 */
public interface Factory {
    
    Actor create ();
    
}
