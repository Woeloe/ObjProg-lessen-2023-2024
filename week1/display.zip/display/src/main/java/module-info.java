module be.ugent.objprog.week1 {
    requires javafx.controls;
    requires javafx.fxml;

    opens be.ugent.objprog.week1 to javafx.fxml;
    exports be.ugent.objprog.week1;
}