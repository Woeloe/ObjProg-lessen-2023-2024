package be.ugent.objprog.week1;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Display extends Application {
    @Override
    public void start(Stage primaryStage) {
        SegmentPanel segmentPanel = new SegmentPanel();
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(10));
        vbox.setStyle("-fx-background-color: #eee");
        SegmentButton button = new SegmentButton(segmentPanel);
        vbox.getChildren().addAll(segmentPanel, button);

        primaryStage.setScene(new Scene(vbox));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
