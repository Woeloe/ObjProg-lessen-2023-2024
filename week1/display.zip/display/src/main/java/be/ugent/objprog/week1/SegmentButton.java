package be.ugent.objprog.week1;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class SegmentButton extends Button implements EventHandler<ActionEvent> {

    private int count;
    private final SegmentPanel panel;

    public SegmentButton (SegmentPanel panel) {
        super ("+ 1");
        this.panel = panel;
        this.count = 0;
        setOnAction(this);
        show (0);
    }

    @Override
    public void handle(ActionEvent event) {
        count = (count + 1) % 4;
        show (count);
    }

    private void show (int digit) {
        if (digit == 0) {
            panel.setOff(0);
            panel.setOn(1);
            panel.setOn(2);
            panel.setOn(3);
            panel.setOn(4);
            panel.setOn(5);
            panel.setOn(6);
        } else if (digit == 1) {
            panel.setOff(0);
            panel.setOff(1);
            panel.setOn(2);
            panel.setOff(3);
            panel.setOff(4);
            panel.setOff(5);
            panel.setOn(6);
        } else if (digit == 2) {
            panel.setOn(0);
            panel.setOff(1);
            panel.setOn(2);
            panel.setOn(3);
            panel.setOn(4);
            panel.setOn(5);
            panel.setOff(6);
        } else { // if (digit == 3)
            panel.setOn(0);
            panel.setOff(1);
            panel.setOn(2);
            panel.setOn(3);
            panel.setOn(4);
            panel.setOff(5);
            panel.setOn(6);
        }
    }
}
