package be.ugent.objprog.week1;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Shape;

public class SegmentPanel extends Pane {

    public SegmentPanel () {
        setPrefHeight(200);
        setPrefWidth (110);
        getChildren().addAll (
                createSegment(55, 100, 0),
                createSegment(10, 55, 90),
                createSegment(100, 55, 90),
                createSegment(55, 10, 0),
                createSegment(55, 190, 0),
                createSegment(10, 145, 90),
                createSegment(100, 145, 90)
        );
    }

    private Shape createSegment (double x, double y, double angle) {
        Shape result =  new Polygon(
                -40.0, 0.0,
                -35.0, -5.0,
                35.0, -5.0,
                40.0, 0.0,
                35.0, 5.0,
                -35.0, 5.0
        );
        result.setStrokeWidth(2.0);
        result.setRotate(angle);
        result.setTranslateX(x);
        result.setTranslateY(y);
        return result;
    }

    public void setOn (int index) {
        Shape shape = (Shape) getChildren().get(index);
        shape.setFill (Color.YELLOW);
        shape.setStroke(Color.BLACK);
    }

    public void setOff (int index) {
        Shape shape = (Shape) getChildren().get(index);
        shape.setFill (Color.LIGHTGREY);
        shape.setStroke(Color.LIGHTGREY);
    }
}
