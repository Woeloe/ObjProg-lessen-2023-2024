// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Toont witte tekst op een grijze achtergrond in een veld van 3 cellen breed
 */
public class Info extends Actor
{

    /**
     * Maak een nieuw info-veld waarin de opgegeven tekst wordt weergegeven.
     */
    public Info(String tekst)
    {
        GreenfootImage achtergrond =  new GreenfootImage(3 * 32, 32);
        achtergrond.setColor(Color.GRAY);
        achtergrond.fill();
        achtergrond.setColor(Color.WHITE);
        achtergrond.setFont( new Font(true, false, 16));
        achtergrond.drawString(tekst, 8, 22);
        setImage(achtergrond);
    }
}
