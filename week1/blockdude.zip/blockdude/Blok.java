// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * Een blok valt naar beneden wanneer het niet gesteund wordt door een ander object.
 */
public class Blok extends Actor
{

    /**
     * Val naar beneden wanneer er niets is dat dit blok ondersteunt
     */
    public void act()
    {
        if (getOneObjectAtOffset(0, 1, Actor.class) == null) {
            setLocation(getX(), getY() + 1);
        }
    }
}
