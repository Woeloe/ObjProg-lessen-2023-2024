// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * De speler die de blokken moet oprapen en plaatsen om te ontsnappen uit de grot
 */
public class Speler extends Actor
{
    /* De richting waarin je kijkt en beweegt. -1 = links +1 = rechts*/
    private int richting;
    /* Het blok dat door de speler gedragen wordt, of null als de speler geen blok draagt*/
    private Actor blok;

    /**
     * Maak een nieuwe speler aan. De parameter 'richting' vertelt in welke richting het mannetje moet kijken: -1 naar links, +1 naar rechts
     */
    public Speler(int richting)
    {
        this.richting = richting;
        updateAfbeelding();
    }

    /**
     * Coordineer de actie van de speler en eventueel het blok dat hij meedraagt
     */
    public void act()
    {
        if (getOneObjectAtOffset(0, 1, Actor.class) == null) {
            /* Niet ondersteund*/
            setLocation(getX(), getY() + 1);
        }
        else {
            /* Wel ondersteund*/
            beweeg();
        }
        if (blok != null) {
            blok.setLocation(getX(), getY() - 1);
        }
        updateAfbeelding();
    }

    /**
     * Beweeg/pak blok op/zet blok af zoals aangegeven door de toetsen
     */
    private void beweeg()
    {
        if (Greenfoot.isKeyDown("left")) {
            richting = -1;
            zetStap();
        }
        else if (Greenfoot.isKeyDown("right")) {
            richting = 1;
            zetStap();
        }
        else if (Greenfoot.isKeyDown("up")) {
            zetStapOmhoog();
        }
        else if (Greenfoot.isKeyDown("down")) {
            if (blok == null) {
                pakBlok();
            }
            else {
                zetBlok();
            }
        }
    }

    /**
     * Pas de afbeelding aan zodat ze overeenkomt met de richting waarin de speler kijkt.
     */
    private void updateAfbeelding()
    {
        if (richting < 0) {
            if (blok == null) {
                setImage("man-links.png");
            }
            else {
                setImage("man-links-blok.png");
            }
        }
        else {
            if (blok == null) {
                setImage("man-rechts.png");
            }
            else {
                setImage("man-rechts-blok.png");
            }
        }
    }

    /**
     * Kan de speler bewegen in de huidige kijkrichting? (Er staat geen actor, tenzij een deur.)
     */
    private boolean kanBewegen()
    {
        return getOneObjectAtOffset(richting, 0, Actor.class) == null || getOneObjectAtOffset(richting, 0, Deur.class) != null;
    }

    /**
     * Kan de speler omhoog bewegen in de huidige kijkrichting?
     */
    private boolean kanOmhoogBewegen()
    {
        /* Onderstaande kan ook zonder if met een enkele return (zoals in 'kanBewegen'), maar dit is niet erg leesbaar*/
        if (getOneObjectAtOffset(richting, 0, Actor.class) == null) {
            return false;
        }
        else if (getOneObjectAtOffset(richting, -1, Deur.class) != null) {
            return true;
        }
        else {
            return getOneObjectAtOffset(richting, -1, Actor.class) == null;
        }
    }

    /**
     * Ga één stap in de kijkrichting, als dit tenminste is toegelaten
     */
    private void zetStap()
    {
        if (kanBewegen()) {
            setLocation(getX() + richting, getY());
        }
    }

    /**
     * Ga één stap omhoog in de kijkrichting, als dit tenminste is toegelaten
     */
    private void zetStapOmhoog()
    {
        if (kanOmhoogBewegen()) {
            setLocation(getX() + richting, getY() - 1);
        }
    }

    /**
     * Neem het blok op dat naast je ligt in de kijkrichting, tenzij er geen is
     */
    private void pakBlok()
    {
        blok = getOneObjectAtOffset(richting, 0, Blok.class);
    }

    /**
     * Zet het blok dat je draagt naast je neer, als er plaats voor is. Plaats het anders eventueel bovenop het object dat naast je staat
     */
    private void zetBlok()
    {
        if (getOneObjectAtOffset(richting, 0, Actor.class) == null) {
            blok.setLocation(getX() + richting, getY());
            blok = null;
        }
        else if (getOneObjectAtOffset(richting, -1, Actor.class) == null) {
            blok.setLocation(getX() + richting, getY() - 1);
            blok = null;
        }
    }
}
