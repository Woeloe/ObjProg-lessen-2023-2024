module be.ugent.objprog.rtf {
    requires javafx.controls;
    requires javafx.fxml;


    opens be.ugent.objprog.rtf to javafx.fxml;
    exports be.ugent.objprog.rtf;
}