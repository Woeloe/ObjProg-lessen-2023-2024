package be.ugent.objprog.rtf;

import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;

import java.io.IOException;

/**
 * Tekstveld met een reset-knop waarmee de gebruiker de waarde kan terugplaatsen naar de laatste waarde
 * die werd ingesteld met setText
 */
public class ResettableTextField extends HBox {

    // moet verwijzen naar het tekstveld uit de partnerklasse
    private final TextField textField;

    public ResettableTextField() throws IOException {
        RTFCompanion companion = new RTFCompanion();
        textField = companion.textField;
        FXMLLoader loader = new FXMLLoader(
                ResettableTextField.class.getResource("ResettableTextField.fxml"));
        loader.setRoot(this);
        loader.setController(companion);
        loader.load();
    }

    public String getText() {
        return textField.getText();
    }

    public void setText(String text) {
        textField.setText(text);
    }

}
