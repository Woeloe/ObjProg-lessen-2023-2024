package be.ugent.objprog.vormen;

public class Herschaal implements VormVisitor<Void>{

    private final double factor;

    public Herschaal(double factor) {
        this.factor = factor;
    }

    @Override
    public Void visitCirkel(Cirkel cirkel) {
        cirkel.setStraal(factor*cirkel.getStraal());
        return null;
    }

    // Simuleert overerving. Zie opmerkingen bij VormVisitor
    private Void visitRechteVorm(RechteVorm vorm) {
        vorm.setBreedte(factor * vorm.getBreedte());
        vorm.setHoogte(factor * vorm.getHoogte());
        return null;
    }

    @Override
    public Void visitRechthoek(Rechthoek rechthoek) {
        return visitRechteVorm(rechthoek); // simuleert overerving
    }

    @Override
    public Void visitRechthoekigeDriehoek(RechthoekigeDriehoek driehoek) {
        return visitRechteVorm(driehoek); // simuleert overerving
    }

    public static void van(Vorm vorm, double factor) {
        vorm.accept(new Herschaal(factor));
    }
}
