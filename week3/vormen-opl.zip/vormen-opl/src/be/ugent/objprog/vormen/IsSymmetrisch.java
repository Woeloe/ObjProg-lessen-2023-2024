package be.ugent.objprog.vormen;

public class IsSymmetrisch implements VormVisitor<Boolean> {

    @Override
    public Boolean visitCirkel(Cirkel cirkel) {
        return true;
    }

    // Simuleert overerving. Zie opmerkingen bij VormVisitor
    private Boolean visitRechteVorm(RechteVorm vorm) {
        return vorm.getBreedte() == vorm.getHoogte();
    }

    @Override
    public Boolean visitRechthoek(Rechthoek rechthoek) {
        return visitRechteVorm(rechthoek); // simuleert overerving
    }

    @Override
    public Boolean visitRechthoekigeDriehoek(RechthoekigeDriehoek driehoek) {
        return visitRechteVorm(driehoek); // simuleert overerving
    }

    public static Boolean van(Vorm vorm) {
        return vorm.accept(new IsSymmetrisch());
    }
}
