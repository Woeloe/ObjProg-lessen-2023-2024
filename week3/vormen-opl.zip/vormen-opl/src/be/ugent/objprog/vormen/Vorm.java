package be.ugent.objprog.vormen;

public interface Vorm {
    <R> R accept (VormVisitor<R> visitor);
}
