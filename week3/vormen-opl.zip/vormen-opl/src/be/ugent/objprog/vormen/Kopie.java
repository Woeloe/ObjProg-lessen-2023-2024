package be.ugent.objprog.vormen;

public class Kopie implements VormVisitor<Vorm> {

    @Override
    public Vorm visitCirkel(Cirkel cirkel) {
        return new Cirkel(cirkel.getStraal());
    }

    @Override
    public Vorm visitRechthoek(Rechthoek rechthoek) {
        return new Rechthoek(rechthoek.getBreedte(), rechthoek.getHoogte());
    }

    @Override
    public Vorm visitRechthoekigeDriehoek(RechthoekigeDriehoek driehoek) {
        return new RechthoekigeDriehoek(driehoek.getBreedte(), driehoek.getHoogte());
    }

    public static Vorm van (Vorm vorm) {
        return vorm.accept(new Kopie());
    }
}
