package be.ugent.objprog.vormen;

public interface VormVisitor<R>  {

    R visitCirkel (Cirkel cirkel);

    R visitRechthoek (Rechthoek rechthoek);

    R visitRechthoekigeDriehoek (RechthoekigeDriehoek driehoek);

    /* Opmerkingen

       Merk op dat we hier geen visitRechteVorm introduceren, in enkele van de implementaties
       van deze visitor-interface doen we dat wel. Daarmee simuleren we een soort overerving.
       Zie IsSymmetrisch en Herschaal.
       Er staat dus ook geen accept in de klasse RechteVorm

     */
}
