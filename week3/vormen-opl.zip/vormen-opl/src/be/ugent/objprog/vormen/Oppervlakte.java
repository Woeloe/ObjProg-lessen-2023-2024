package be.ugent.objprog.vormen;

public class Oppervlakte implements VormVisitor<Double>{

    @Override
    public Double visitCirkel(Cirkel cirkel) {
        return cirkel.getStraal()*cirkel.getStraal()*Math.PI;
    }

    @Override
    public Double visitRechthoek(Rechthoek rechthoek) {
        return rechthoek.getBreedte() * rechthoek.getHoogte();
    }

    @Override
    public Double visitRechthoekigeDriehoek(RechthoekigeDriehoek driehoek) {
        return driehoek.getBreedte() * driehoek.getHoogte() / 2;
    }

    /* Opmerking

       In de plaats van getBreedte(), getHoogte() en getStraal() zou je in principe ook gewoon
       breedte, hoogte en straal kunnen schrijven, omdat protected velden in Java ook zichtbaar
       zijn voor andere klassen binnen hetzelfde pakket.

       Mocht men Java nu heruitvinden, dan zou men dat misschien
       niet meer toelaten - kijk maar naar Kotlin. Wij misbruiken dit daarom ook niet.
     */

    public static Double van (Vorm vorm) {
        return vorm.accept(new Oppervlakte());
    }

}
