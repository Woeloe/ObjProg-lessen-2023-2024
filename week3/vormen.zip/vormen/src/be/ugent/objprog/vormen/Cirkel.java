package be.ugent.objprog.vormen;

public class Cirkel implements Vorm {

    private double straal;

    public Cirkel(double straal) {
        this.straal = straal;
    }

    public double getStraal() {
        return straal;
    }

    public void setStraal(double straal) {
        this.straal = straal;
    }

    @Override
    public double oppervlakte() {
        return straal*straal*Math.PI;
    }

    @Override
    public void herschaal(double factor) {
        straal *= factor;
    }

    @Override
    public boolean isSymmetrisch() {
        return true;
    }

    @Override
    public Vorm kopie() {
        return new Cirkel(straal);
    }
}
