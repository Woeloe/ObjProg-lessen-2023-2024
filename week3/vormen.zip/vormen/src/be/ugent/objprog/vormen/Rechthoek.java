package be.ugent.objprog.vormen;

public class Rechthoek extends RechteVorm {

    public Rechthoek(double breedte, double hoogte) {
        super(breedte, hoogte);
    }

    @Override
    public double oppervlakte() {
        return breedte * hoogte;
    }

    @Override
    public Vorm kopie() {
        return new Rechthoek(breedte, hoogte);
    }
}
