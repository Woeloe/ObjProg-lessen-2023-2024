package be.ugent.objprog.vormen;

public class RechthoekigeDriehoek extends RechteVorm {

    public RechthoekigeDriehoek(double breedte, double hoogte) {
        super(breedte, hoogte);
    }

    @Override
    public double oppervlakte() {
        return breedte*hoogte/2.0;
    }

    @Override
    public Vorm kopie() {
        return new RechthoekigeDriehoek(breedte, hoogte);
    }
    
}
