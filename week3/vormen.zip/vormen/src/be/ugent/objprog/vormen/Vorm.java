package be.ugent.objprog.vormen;

/**
 * Geeft aan welke bewerkingen er op alle ondersteunde vormen moeten worden toegestaan
 */
public interface Vorm {

    // Oppervlakte van de vorm
    double oppervlakte ();

    // Vergroot de vorm met de gegeven factor
    void herschaal(double factor);

    // Is deze vorm symmetrisch t.o.v. de bissectrice van de X- en Y-as?
    boolean isSymmetrisch();

    // Maak een kopie van deze vorm (nieuw object met dezelfde 'inhoud')
    Vorm kopie ();
}
