package be.ugent.jvl.countdown;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.util.Duration;

public class CountdownPane extends BorderPane {

    private int tijd;

    private static final int START_WAARDE = 20;

    public final Label label;

    private final Timeline timeline;

    public CountdownPane () {

        setPrefHeight(200.0);
        setPrefWidth(300.0);
        getStylesheets().add(getClass().getResource("/be/ugent/jvl/countdown/countdown.css").toString());

        label = new Label ("(leeg");
        label.setId("teller");
        setCenter(label);
        setAlignment(label, Pos.CENTER);

        Button button = new Button ("Start");
        setBottom(button);
        setAlignment(button, Pos.CENTER);
        button.setOnAction(this::startTimer);

        timeline = new Timeline(
                new KeyFrame(Duration.seconds(1.0), e -> puls())
        );
        timeline.setCycleCount(START_WAARDE); // stopt na één keer
    }

    private void puls() {
        if (tijd <= 1) {
            label.setText ("EINDE");
        } else {
            tijd --;
            label.setText (String.format ("%03d", tijd));
        }
        if (tijd == 10) {
            label.getStyleClass().add ("alarm");
        }
    }

    public void startTimer (ActionEvent event) {
        label.getStyleClass().remove ("alarm");
        tijd = START_WAARDE + 1;
        puls ();
        timeline.playFromStart();
    }
}
